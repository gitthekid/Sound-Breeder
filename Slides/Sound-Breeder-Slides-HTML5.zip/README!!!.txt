IMPORTANT: Make sure to extract files from zip archive to your local folder. DO NOT OPEN IT DIRECTLY WITHIN THE ARCHIVE.

How to extract files to your local: 
Mac: Double click the .zip file to unzip it. 
PC: Right click the .zip file and then select Extract All

This project was created using Visme, an easy to use online platform allowing anyone to create awesome presentations, infographics and other visual content right in their browser. 
Tips to present your project offline: 
1). Make sure to extract files from zip folder to your local folder. 
2). Then open the index.html in any browser offline.  (Google Chrome is recommended) 



Also for full presentation you can also visit the Online version at: 
https://my.visme.co/view/vdkepm1w-untitled-project
For more tips on HTML5 download visit support topic:
http://support.visme.co/knowledgebase/downloading-projects-for-offline-use/

Don’t have a Visme account? Visit www.visme.co to create your new account."
